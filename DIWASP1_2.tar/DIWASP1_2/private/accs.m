function trm=accs(ffreqs,dirs,wns,z,depth)

trm=-(ffreqs.*ffreqs)*ones(size(dirs));