function [S, f] = diwasp_csd(x,y,nfft,fs)
%Diwasp cross spectral density.
%If CPSD is available from Matlab Signal Processing Toolbox, then use that.
%Other wise this function will calc cross-spectra density using inbuilf FFT function
%
%[Pxy, f] = diwasp_csd(x,y,nfft,fs)
%
%

if exist('cpsd')==2
    [S, f] = cpsd(x,y,nfft,0,nfft,fs);
elseif exist('csd')==2
    [S, f] = csd(x,y,nfft,fs);
else
    %Make a windowed estimate of CSD
    hann=0.5*(1-cos(2*pi*(1:nfft/2)/(nfft+1)));
    win = [hann hann(end:-1:1)];
    nw = length(win);
    nseg=fix(length(x)/nw);
    S = zeros(nfft,1);
    for iseg=0:nseg-1
        ind=nw*iseg+[1:nw];
        xw = win'.*x(ind);
        yw = win'.*y(ind);
        Px = fft(xw,nfft);
        Py = fft(yw,nfft);
        Pxy = Py.*conj(Px);
        S = S + Pxy;
    end
    S=S(1:nfft/2+1)/(nseg*norm(win)^2);
    f=(fs/nfft)*[0:nfft/2]';
end
